
package employeetest2;


public class EmployeeTest2 {

    public static void main(String[] args) {
           employee obj = new employee("Shakar","Tahsin",2000);
        employee obj1 = new employee("Diana","Alex",3000);
    
     System.out.println("Name\t\t\t"+"year salary\n"+"****\t\t\t***********");
    obj.display();
    obj1.display();
        System.out.println();
        System.out.println("10 Percent salary raised!! Yoohooo! ");
     System.out.println("Name\t\t\t"+"year salary\n"+"****\t\t\t***********");
     obj.displayAfterUpdate();
     obj1.displayAfterUpdate();
    }
    
    
    }
    

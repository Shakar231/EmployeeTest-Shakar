
package employeetest2;


public class employee {
      private String firstname;
   private String lastname;
   private double monthlysalary;
   
   public String getlastname (){
       return lastname;
   }
   
   public String getfirstname (){
       return firstname;
   }
   
    public double getmonthlysalary (){
       return monthlysalary;
   }
   
   public  employee (String firstname,String lastname,double monthlysalary){
       this.firstname = firstname;
       this.lastname=lastname;
       if (monthlysalary>0)
           this.monthlysalary =monthlysalary*12;
           else
           this.monthlysalary=0;
       
   }
   
   
   
    
    public void display(){
       
        System.out.println(getfirstname()+" "+getlastname()+"\t\t$"+getmonthlysalary());
    }
     public void displayAfterUpdate(){
       double x =getmonthlysalary()+(getmonthlysalary()/10);
        System.out.println(getfirstname()+" "+getlastname()+"\t\t$"+x);
    }
   
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
